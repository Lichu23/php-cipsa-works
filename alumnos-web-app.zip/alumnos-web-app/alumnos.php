<?php
$alumnos = [
    ["nombre" => "Pepe", "apellido1" => "Sanchez", "apellido2" => "Gonzales", "cuenta" => "pep", "calificacion" => 10],
    ["nombre" => "Maria", "apellido1" => "Lopez", "apellido2" => "Hernandez", "cuenta" => "mar", "calificacion" => 9],
    ["nombre" => "Luis", "apellido1" => "Perez", "apellido2" => "Torres", "cuenta" => "lui", "calificacion" => 8],
    ["nombre" => "Ana", "apellido1" => "Gomez", "apellido2" => "Diaz", "cuenta" => "ana", "calificacion" => 7],
    ["nombre" => "Carlos", "apellido1" => "Martinez", "apellido2" => "Ruiz", "cuenta" => "car", "calificacion" => 6],
    ["nombre" => "Sofia", "apellido1" => "Morales", "apellido2" => "Castro", "cuenta" => "sof", "calificacion" => 10],
    ["nombre" => "Diego", "apellido1" => "Fernandez", "apellido2" => "Nunez", "cuenta" => "die", "calificacion" => 9],
    ["nombre" => "Lucia", "apellido1" => "Ramirez", "apellido2" => "Ortiz", "cuenta" => "luc", "calificacion" => 8],
    ["nombre" => "Pablo", "apellido1" => "Vega", "apellido2" => "Silva", "cuenta" => "pab", "calificacion" => 7],
    ["nombre" => "Elena", "apellido1" => "Rojas", "apellido2" => "Cruz", "cuenta" => "ele", "calificacion" => 6],
    ["nombre" => "Jorge", "apellido1" => "Jimenez", "apellido2" => "Delgado", "cuenta" => "jor", "calificacion" => 10],
    ["nombre" => "Clara", "apellido1" => "Mendoza", "apellido2" => "Santos", "cuenta" => "cla", "calificacion" => 9],
    ["nombre" => "Raul", "apellido1" => "Guerrero", "apellido2" => "Pineda", "cuenta" => "rau", "calificacion" => 8],
    ["nombre" => "Isabel", "apellido1" => "Reyes", "apellido2" => "Navarro", "cuenta" => "isa", "calificacion" => 7],
    ["nombre" => "Victor", "apellido1" => "Campos", "apellido2" => "Dominguez", "cuenta" => "vic", "calificacion" => 6],
    ["nombre" => "Laura", "apellido1" => "Aguilar", "apellido2" => "Flores", "cuenta" => "lau", "calificacion" => 10],
    ["nombre" => "Antonio", "apellido1" => "Salazar", "apellido2" => "Cervantes", "cuenta" => "ant", "calificacion" => 9],
    ["nombre" => "Marta", "apellido1" => "Cabrera", "apellido2" => "Ramos", "cuenta" => "mar2", "calificacion" => 8],
    ["nombre" => "Andres", "apellido1" => "Ortiz", "apellido2" => "Valdez", "cuenta" => "and", "calificacion" => 7],
    ["nombre" => "Gabriela", "apellido1" => "Castillo", "apellido2" => "Serrano", "cuenta" => "gab", "calificacion" => 6],
    ["nombre" => "Pedro", "apellido1" => "Hernandez", "apellido2" => "Lozano", "cuenta" => "ped", "calificacion" => 10]
];

?>
